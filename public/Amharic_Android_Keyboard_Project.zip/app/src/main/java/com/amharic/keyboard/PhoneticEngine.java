package com.amharic.keyboard;

import java.util.HashMap;
import java.util.Map;

/**
 * Pure Java Implementation of Windows 10 Amharic Phonetic Engine.
 * Compatible with Android 2.4 (Froyo/Gingerbread) up to Android 15.
 */
public class PhoneticEngine {

    public static class Result {
        public final String outputChar;
        public final int replaceLength;
        public final String newBuffer;

        public Result(String outputChar, int replaceLength, String newBuffer) {
            this.outputChar = outputChar;
            this.replaceLength = replaceLength;
            this.newBuffer = newBuffer;
        }
    }

    // Amharic Consonant Family Mappings (Order 1 through 7 + Labialized 8th Order)
    private static final Map<String, String[]> FAMILIES = new HashMap<String, String[]>();

    static {
        // Index: 0=1st, 1=2nd, 2=3rd, 3=4th, 4=5th, 5=6th, 6=7th, 7=labialized
        FAMILIES.put("h", new String[]{"ሀ", "ሁ", "ሂ", "ሃ", "ሄ", "ህ", "ሆ", "ኋ"});
        FAMILIES.put("H", new String[]{"ሐ", "ሑ", "ሒ", "ሓ", "ሔ", "ሕ", "ሖ", "ሗ"});
        FAMILIES.put("l", new String[]{"ለ", "ሉ", "ሊ", "ላ", "ሌ", "ል", "ሎ", "ሏ"});
        FAMILIES.put("m", new String[]{"መ", "ሙ", "ሚ", "ማ", "ሜ", "ም", "ሞ", "ሟ"});
        FAMILIES.put("r", new String[]{"ረ", "ሩ", "ሪ", "ራ", "ሬ", "ር", "ሮ", "ሯ"});
        FAMILIES.put("s", new String[]{"ሰ", "ሱ", "ሲ", "ሳ", "ሴ", "ስ", "ሶ", "ሷ"});
        FAMILIES.put("S", new String[]{"ሠ", "ሡ", "ሢ", "ሣ", "ሤ", "ሥ", "ሦ", "ሧ"});
        FAMILIES.put("q", new String[]{"ቀ", "ቁ", "ቂ", "ቃ", "ቄ", "ቅ", "ቆ", "ቋ"});
        FAMILIES.put("b", new String[]{"በ", "ቡ", "ቢ", "ባ", "ቤ", "ብ", "ቦ", "ቧ"});
        FAMILIES.put("v", new String[]{"ቨ", "ቩ", "ቪ", "ቫ", "ቬ", "ቭ", "ቮ", "ቯ"});
        FAMILIES.put("t", new String[]{"ተ", "ቱ", "ቲ", "ታ", "ቴ", "ት", "ቶ", "ቷ"});
        FAMILIES.put("ch", new String[]{"ቸ", "ቹ", "ቺ", "ቻ", "ቼ", "ች", "ቾ", "ቿ"});
        FAMILIES.put("n", new String[]{"ነ", "ኑ", "ኒ", "ና", "ኔ", "ን", "ኖ", "ኗ"});
        FAMILIES.put("N", new String[]{"ኘ", "ኙ", "ኚ", "ኛ", "፜", "ኝ", "ኞ", "፝"});
        FAMILIES.put("ny", new String[]{"ኘ", "ኙ", "ኚ", "ኛ", "፜", "ኝ", "ኞ", "፝"});
        FAMILIES.put("a", new String[]{"አ", "ኡ", "ኢ", "ኣ", "ኤ", "እ", "ኦ", "ኧ"});
        FAMILIES.put("A", new String[]{"ዐ", "ዑ", "ዒ", "ዓ", "ዔ", "ዕ", "ዖ", ""});
        FAMILIES.put("k", new String[]{"ከ", "ኩ", "ኪ", "ካ", "ኬ", "ክ", "ኮ", "ኳ"});
        FAMILIES.put("w", new String[]{"ወ", "ዉ", "ዊ", "ዋ", "ዌ", "ው", "ዎ", ""});
        FAMILIES.put("z", new String[]{"ዘ", "ዙ", "ዚ", "ዛ", "ዜ", "ዝ", "ዞ", "ዟ"});
        FAMILIES.put("Z", new String[]{"ዠ", "ዡ", "ዢ", "ዣ", "ዤ", "ዥ", "ዦ", "ዧ"});
        FAMILIES.put("zh", new String[]{"ዠ", "ዡ", "ዢ", "ዣ", "ዤ", "ዥ", "ዦ", "ዧ"});
        FAMILIES.put("y", new String[]{"የ", "ዩ", "ዪ", "ያ", "ዬ", "ይ", "ዮ", ""});
        FAMILIES.put("d", new String[]{"ደ", "ዱ", "ዲ", "ዳ", "ዴ", "ድ", "ዶ", "ዷ"});
        FAMILIES.put("j", new String[]{"ጀ", "ጁ", "ጂ", "ጃ", "ጄ", "ጅ", "ጆ", "ጇ"});
        FAMILIES.put("g", new String[]{"ገ", "ጉ", "ጊ", "ጋ", "ጌ", "ግ", "ጎ", "ጓ"});
        FAMILIES.put("T", new String[]{"ጠ", "ጡ", "ጢ", "ጣ", "ጤ", "ጥ", "ጦ", "ጧ"});
        FAMILIES.put("C", new String[]{"ጨ", "ጩ", "ጪ", "ጫ", "ጬ", "ጭ", "ጮ", "ጯ"});
        FAMILIES.put("P", new String[]{"ጰ", "ጱ", "ጲ", "ጳ", "ጴ", "ጵ", "ጶ", "ጷ"});
        FAMILIES.put("ts", new String[]{"ጸ", "ጹ", "ጺ", "ጻ", "ጼ", "ጽ", "ጾ", "ጿ"});
        FAMILIES.put("f", new String[]{"ፈ", "ፉ", "ፊ", "ፋ", "ፌ", "ፍ", "ፎ", "ፏ"});
        FAMILIES.put("p", new String[]{"ፐ", "ፑ", "ፒ", "ፓ", "ፔ", "ፕ", "ፖ", "ፗ"});
    }

    public static Result processKey(String key, String currentBuffer) {
        String combined = currentBuffer + key;

        // Punctuation
        if (key.equals(":") && currentBuffer.equals(":")) return new Result("፡", 1, "");
        if (key.equals(":") && currentBuffer.equals("::")) return new Result("።", 1, "");

        // Digraphs
        if (combined.equals("ch") || combined.equals("zh") || combined.equals("ny") || combined.equals("ts")) {
            String[] orders = FAMILIES.get(combined);
            return new Result(orders[0], currentBuffer.length(), combined);
        }

        // Active consonant buffer conversion via vowel modifiers
        if (currentBuffer.length() > 0 && FAMILIES.containsKey(currentBuffer)) {
            String[] orders = FAMILIES.get(currentBuffer);
            if (key.equalsIgnoreCase("u")) return new Result(orders[1], 1, "");
            if (key.equalsIgnoreCase("i")) return new Result(orders[2], 1, "");
            if (key.equalsIgnoreCase("a")) return new Result(orders[3], 1, "");
            if (key.equalsIgnoreCase("e")) return new Result(orders[4], 1, "");
            if (key.equals("I")) return new Result(orders[5], 1, "");
            if (key.equalsIgnoreCase("o")) return new Result(orders[6], 1, "");
            if (key.equalsIgnoreCase("w") && orders.length > 7 && !orders[7].isEmpty()) return new Result(orders[7], 1, "");
        }

        // New consonant key
        if (FAMILIES.containsKey(key)) {
            String[] orders = FAMILIES.get(key);
            return new Result(orders[0], 0, key);
        }

        // Default fallback
        return new Result(key, 0, "");
    }
}
