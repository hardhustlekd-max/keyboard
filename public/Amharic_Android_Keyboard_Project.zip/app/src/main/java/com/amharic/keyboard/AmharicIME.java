package com.amharic.keyboard;

import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Toast;

/**
 * Ultra-Lightweight Amharic Soft Keyboard (InputMethodService)
 * 
 * Supports all Android versions from Android 2.4 (Gingerbread/API 8+) up to Android 15 (API 35+).
 * Features dedicated Language Locking state (English default vs. Windows 10 Amharic Phonetic).
 * Zero external runtime dependencies to keep memory consumption under 2MB.
 */
public class AmharicIME extends InputMethodService implements KeyboardView.OnKeyboardActionListener {

    // Custom Key Codes for Keyboard XML
    public static final int KEYCODE_LANG_LOCK = -101; // Dedicated Language Lock Toggle
    public static final int KEYCODE_SHIFT = Keyboard.KEYCODE_SHIFT;
    public static final int KEYCODE_DELETE = Keyboard.KEYCODE_DELETE;
    public static final int KEYCODE_DONE = Keyboard.KEYCODE_DONE;

    private KeyboardView mKeyboardView;
    private Keyboard mQwertyKeyboard;
    
    // Core IME States
    private boolean isAmharicLocked = false; // Language Lock state (Default = English)
    private boolean isShifted = false;
    private String currentSyllableBuffer = ""; // Uncommitted QWERTY sequence for Amharic composition

    @Override
    public View onCreateInputView() {
        // Inflate lightweight KeyboardView layout (compatible back to Android 2.4 / API 8)
        mKeyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        mQwertyKeyboard = new Keyboard(this, R.xml.qwerty_layout);
        mKeyboardView.setKeyboard(mQwertyKeyboard);
        mKeyboardView.setOnKeyboardActionListener(this);
        return mKeyboardView;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (primaryCode) {
            case KEYCODE_LANG_LOCK:
                // Toggle Language Lock between English & Windows 10 Amharic Phonetic
                isAmharicLocked = !isAmharicLocked;
                currentSyllableBuffer = ""; // Clear active buffer on language switch
                
                String toastMsg = isAmharicLocked ? 
                    "Amharic Language LOCKED (Windows 10 Phonetic)" : 
                    "English Language LOCKED";
                Toast.makeText(this, toastMsg, Toast.LENGTH_SHORT).show();
                
                updateKeyboardLabels();
                break;

            case KEYCODE_DELETE:
                if (currentSyllableBuffer.length() > 0) {
                    currentSyllableBuffer = "";
                }
                ic.deleteSurroundingText(1, 0);
                break;

            case KEYCODE_SHIFT:
                isShifted = !isShifted;
                mQwertyKeyboard.setShifted(isShifted);
                mKeyboardView.invalidateAllKeys();
                break;

            case KEYCODE_DONE:
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
                currentSyllableBuffer = "";
                break;

            default:
                char codeChar = (char) primaryCode;
                
                if (isShifted) {
                    codeChar = Character.toUpperCase(codeChar);
                    isShifted = false; // Reset single shift
                    mQwertyKeyboard.setShifted(false);
                    mKeyboardView.invalidateAllKeys();
                }

                if (isAmharicLocked) {
                    // Process key through Windows 10 Amharic Phonetic Engine
                    PhoneticEngine.Result res = PhoneticEngine.processKey(String.valueOf(codeChar), currentSyllableBuffer);
                    
                    if (res.replaceLength > 0) {
                        ic.deleteSurroundingText(res.replaceLength, 0);
                    }
                    ic.commitText(res.outputChar, 1);
                    currentSyllableBuffer = res.newBuffer;
                } else {
                    // Standard English input mode
                    ic.commitText(String.valueOf(codeChar), 1);
                    currentSyllableBuffer = "";
                }
                break;
        }
    }

    private void updateKeyboardLabels() {
        if (mKeyboardView != null) {
            mKeyboardView.invalidateAllKeys();
        }
    }

    @Override
    public void onPress(int primaryCode) {}
    @Override
    public void onRelease(int primaryCode) {}
    @Override
    public void onText(CharSequence text) {}
    @Override
    public void swipeLeft() {}
    @Override
    public void swipeRight() {}
    @Override
    public void swipeDown() {}
    @Override
    public void swipeUp() {}
}
