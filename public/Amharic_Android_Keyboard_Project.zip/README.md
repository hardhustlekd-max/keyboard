# Amharic Windows Phonetic Android Keyboard (Native IME)

This is a complete Native Android Soft Keyboard (InputMethodService) project compatible with Android 2.4+ (API 8) through Android 15+ (API 35).

## Build Instructions in Android Studio
1. Open Android Studio -> "Open an existing project".
2. Select this directory.
3. Click "Build" -> "Build Bundle(s) / APK(s)" -> "Build APK(s)".
4. Output `app-debug.apk` will be created in `app/build/outputs/apk/debug/`.
