package com.amharic.keyboard

/**
 * Pure Kotlin Implementation of Windows 10 Amharic Phonetic Composition Engine.
 * Supports all 7 orders + labialized forms + digraphs + Geez numerals & punctuation.
 */
object PhoneticEngineKt {

    data class Result(
        val outputChar: String,
        val replaceLength: Int,
        val newBuffer: String
    )

    private val FAMILIES = mapOf(
        "h" to arrayOf("ሀ", "ሁ", "ሂ", "ሃ", "ሄ", "ህ", "ሆ", "ኋ"),
        "H" to arrayOf("ሐ", "ሑ", "ሒ", "ሓ", "ሔ", "ሕ", "ሖ", "ሗ"),
        "l" to arrayOf("ለ", "ሉ", "ሊ", "ላ", "ሌ", "ል", "ሎ", "ሏ"),
        "m" to arrayOf("መ", "ሙ", "ሚ", "ማ", "ሜ", "ም", "ሞ", "ሟ"),
        "r" to arrayOf("ረ", "ሩ", "ሪ", "ራ", "ሬ", "ር", "ሮ", "ሯ"),
        "s" to arrayOf("ሰ", "ሱ", "ሲ", "ሳ", "ሴ", "ስ", "ሶ", "ሷ"),
        "S" to arrayOf("ሠ", "ሡ", "ሢ", "ሣ", "ሤ", "ሥ", "ሦ", "ሧ"),
        "q" to arrayOf("ቀ", "ቁ", "ቂ", "ቃ", "ቄ", "ቅ", "ቆ", "ቋ"),
        "b" to arrayOf("በ", "ቡ", "ቢ", "ባ", "ቤ", "ብ", "ቦ", "ቧ"),
        "v" to arrayOf("ቨ", "ቩ", "ቪ", "ቫ", "ቬ", "ቭ", "ቮ", "ቯ"),
        "t" to arrayOf("ተ", "ቱ", "ቲ", "ታ", "ቴ", "ት", "ቶ", "ቷ"),
        "ch" to arrayOf("ቸ", "ቹ", "ቺ", "ቻ", "ቼ", "ች", "ቾ", "ቿ"),
        "n" to arrayOf("ነ", "ኑ", "ኒ", "ና", "ኔ", "ን", "ኖ", "ኗ"),
        "N" to arrayOf("ኘ", "ኙ", "ኚ", "ኛ", "፜", "ኝ", "ኞ", "፝"),
        "ny" to arrayOf("ኘ", "ኙ", "ኚ", "ኛ", "፜", "ኝ", "ኞ", "፝"),
        "a" to arrayOf("አ", "ኡ", "ኢ", "ኣ", "ኤ", "እ", "ኦ", "ኧ"),
        "A" to arrayOf("ዐ", "ዑ", "ዒ", "ዓ", "ዔ", "ዕ", "ዖ", ""),
        "k" to arrayOf("ከ", "ኩ", "ኪ", "ካ", "ኬ", "ክ", "ኮ", "ኳ"),
        "w" to arrayOf("ወ", "ዉ", "ዊ", "ዋ", "ዌ", "ው", "ዎ", ""),
        "z" to arrayOf("ዘ", "ዙ", "ዚ", "ዛ", "ዜ", "ዝ", "ዞ", "ዟ"),
        "Z" to arrayOf("ዠ", "ዡ", "ዢ", "ዣ", "ዤ", "ዥ", "ዦ", "ዧ"),
        "zh" to arrayOf("ዠ", "ዡ", "ዢ", "ዣ", "ዤ", "ዥ", "ዦ", "ዧ"),
        "y" to arrayOf("የ", "ዩ", "ዪ", "ያ", "ዬ", "ይ", "ዮ", ""),
        "d" to arrayOf("ደ", "ዱ", "ዲ", "ዳ", "ዴ", "ድ", "ዶ", "ዷ"),
        "j" to arrayOf("ጀ", "ጁ", "ጂ", "ጃ", "ጄ", "ጅ", "ጆ", "ጇ"),
        "g" to arrayOf("ገ", "ጉ", "ጊ", "ጋ", "ጌ", "ግ", "ጎ", "ጓ"),
        "T" to arrayOf("ጠ", "ጡ", "ጢ", "ጣ", "ጤ", "ጥ", "ጦ", "ጧ"),
        "C" to arrayOf("ጨ", "ጩ", "ጪ", "ጫ", "ጬ", "ጭ", "ጮ", "ጯ"),
        "P" to arrayOf("ጰ", "ጱ", "ጲ", "ጳ", "ጴ", "ጵ", "ጶ", "ፗ"),
        "ts" to arrayOf("ጸ", "ጹ", "ጺ", "ጻ", "ጼ", "ጽ", "ጾ", "<ctrl42>"),
        "f" to arrayOf("ፈ", "ፉ", "ፊ", "ፋ", "ፌ", "ፍ", "ፎ", "ፏ"),
        "p" to arrayOf("ፐ", "ፑ", "ፒ", "ፓ", "ፔ", "ፕ", "ፖ", "ፗ")
    )

    fun processKey(key: String, currentBuffer: String): Result {
        val combined = currentBuffer + key

        // Punctuation
        if (key == ":" && currentBuffer == ":") return Result("፡", 1, "")
        if (key == ":" && currentBuffer == "::") return Result("።", 1, "")

        // Digraphs (ch, zh, ny, ts)
        if (combined in setOf("ch", "zh", "ny", "ts")) {
            val orders = FAMILIES[combined] ?: return Result(key, 0, "")
            return Result(orders[0], currentBuffer.length, combined)
        }

        // Active consonant buffer conversion via vowel modifiers
        if (currentBuffer.isNotEmpty() && FAMILIES.containsKey(currentBuffer)) {
            val orders = FAMILIES[currentBuffer]!!
            return when (key.lowercase()) {
                "u" -> Result(orders[1], 1, "")
                "i" -> Result(orders[2], 1, "")
                "a" -> Result(orders[3], 1, "")
                "e" -> Result(orders[4], 1, "")
                "o" -> Result(orders[6], 1, "")
                "w" -> if (orders.size > 7 && orders[7].isNotEmpty()) Result(orders[7], 1, "") else Result(key, 0, "")
                else -> {
                    if (key == "I") Result(orders[5], 1, "")
                    else if (FAMILIES.containsKey(key)) {
                        val newOrders = FAMILIES[key]!!
                        Result(newOrders[0], 0, key)
                    } else Result(key, 0, "")
                }
            }
        }

        // New consonant key
        if (FAMILIES.containsKey(key)) {
            val orders = FAMILIES[key]!!
            return Result(orders[0], 0, key)
        }

        return Result(key, 0, "")
    }

    fun getSuggestions(buffer: String): List<String> {
        val orders = FAMILIES[buffer] ?: return emptyList()
        return orders.filter { it.isNotEmpty() }.toList()
    }
}
