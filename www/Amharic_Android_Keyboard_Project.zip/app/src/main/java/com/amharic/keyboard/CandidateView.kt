package com.amharic.keyboard

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class CandidateView(context: Context) : LinearLayout(context) {

    private var service: AmharicIME? = null

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(Color.parseColor("#1E293B"))
        setPadding(16, 8, 16, 8)
    }

    fun setService(ime: AmharicIME) {
        this.service = ime
    }

    fun updateCandidates(candidates: List<String>) {
        removeAllViews()
        for (cand in candidates) {
            val tv = TextView(context).apply {
                text = cand
                textSize = 18f
                setTextColor(Color.WHITE)
                setPadding(24, 12, 24, 12)
                setOnClickListener {
                    service?.pickCandidate(cand)
                }
            }
            addView(tv)
        }
    }
}
