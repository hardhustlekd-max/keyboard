package com.amharic.keyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Toast

/**
 * Native Kotlin Amharic Soft Keyboard (InputMethodService)
 * 
 * Compatible with Android 2.4 (API 8) up to Android 15 (API 35+).
 * Implements dedicated Language Locking (English default vs. Windows 10 Amharic Phonetic).
 */
class AmharicIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    companion object {
        const val KEYCODE_LANG_LOCK = -101 // Dedicated Language Lock Toggle
        const val KEYCODE_SHIFT = Keyboard.KEYCODE_SHIFT
        const val KEYCODE_DELETE = Keyboard.KEYCODE_DELETE
        const val KEYCODE_DONE = Keyboard.KEYCODE_DONE
    }

    private var keyboardView: KeyboardView? = null
    private var qwertyKeyboard: Keyboard? = null
    
    // Core IME State
    private var isAmharicLocked = false
    private var isShifted = false
    private var currentSyllableBuffer = ""

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as KeyboardView
        qwertyKeyboard = Keyboard(this, R.xml.qwerty_layout)
        keyboardView?.apply {
            keyboard = qwertyKeyboard
            setOnKeyboardActionListener(this@AmharicIME)
        }
        return keyboardView!!
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic: InputConnection = currentInputConnection ?: return

        when (primaryCode) {
            KEYCODE_LANG_LOCK -> {
                // Toggle Language Lock between English & Windows 10 Amharic Phonetic
                isAmharicLocked = !isAmharicLocked
                currentSyllableBuffer = ""
                
                val msg = if (isAmharicLocked) 
                    "Amharic Language LOCKED (Windows 10 Phonetic)" 
                else 
                    "English Language LOCKED"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                
                keyboardView?.invalidateAllKeys()
            }

            KEYCODE_DELETE -> {
                if (currentSyllableBuffer.isNotEmpty()) {
                    currentSyllableBuffer = ""
                }
                ic.deleteSurroundingText(1, 0)
            }

            KEYCODE_SHIFT -> {
                isShifted = !isShifted
                qwertyKeyboard?.isShifted = isShifted
                keyboardView?.invalidateAllKeys()
            }

            KEYCODE_DONE -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                currentSyllableBuffer = ""
            }

            else -> {
                var codeChar = primaryCode.toChar()
                
                if (isShifted) {
                    codeChar = codeChar.uppercaseChar()
                    isShifted = false
                    qwertyKeyboard?.isShifted = false
                    keyboardView?.invalidateAllKeys()
                }

                if (isAmharicLocked) {
                    // Process through Kotlin Windows 10 Amharic Phonetic Engine
                    val res = PhoneticEngineKt.processKey(codeChar.toString(), currentSyllableBuffer)
                    
                    if (res.replaceLength > 0) {
                        ic.deleteSurroundingText(res.replaceLength, 0)
                    }
                    ic.commitText(res.outputChar, 1)
                    currentSyllableBuffer = res.newBuffer
                } else {
                    // Standard English input mode
                    ic.commitText(codeChar.toString(), 1)
                    currentSyllableBuffer = ""
                }
            }
        }
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
