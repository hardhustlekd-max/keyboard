package com.amharic.keyboard

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.media.AudioManager
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Toast

/**
 * Full-featured Native Kotlin Amharic Soft Keyboard (Gboard Style InputMethodService).
 * Compatible with Android 2.4 (API 8) through Android 15 (API 35+).
 */
class AmharicIME : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    companion object {
        const val KEYCODE_LANG_LOCK = -101 // Dedicated Language Lock Toggle Key
        const val KEYCODE_EMOJI = -102     // Emoji Panel Switcher
        const val KEYCODE_SYMBOLS = -103   // Symbols Layer Switcher
        const val KEYCODE_SHIFT = Keyboard.KEYCODE_SHIFT
        const val KEYCODE_DELETE = Keyboard.KEYCODE_DELETE
        const val KEYCODE_DONE = Keyboard.KEYCODE_DONE
    }

    private var keyboardView: KeyboardView? = null
    private var qwertyKeyboard: Keyboard? = null
    private var symbolsKeyboard: Keyboard? = null
    private var candidateView: CandidateView? = null
    
    private var vibrator: Vibrator? = null
    private var audioManager: AudioManager? = null

    // IME Settings & State
    private var isAmharicLocked = true
    private var isShifted = false
    private var isSymbolsMode = false
    private var enableSound = true
    private var enableVibration = true
    private var currentSyllableBuffer = ""

    override fun onCreate() {
        super.onCreate()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as KeyboardView
        qwertyKeyboard = Keyboard(this, R.xml.qwerty_layout)
        symbolsKeyboard = Keyboard(this, R.xml.symbols_layout)

        keyboardView?.apply {
            keyboard = qwertyKeyboard
            setOnKeyboardActionListener(this@AmharicIME)
            isPreviewEnabled = true // Enable Gboard Key Popup Bubble preview
        }
        return keyboardView!!
    }

    override fun onCreateCandidatesView(): View? {
        candidateView = CandidateView(this).apply {
            setService(this@AmharicIME)
        }
        return candidateView
    }

    override fun onStartInput(attribute: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        currentSyllableBuffer = ""
        candidateView?.updateCandidates(emptyList())
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic: InputConnection = currentInputConnection ?: return

        // Trigger Audio & Haptic Feedback
        playFeedback()

        when (primaryCode) {
            KEYCODE_LANG_LOCK -> {
                // Toggle Language Lock between English & Windows 10 Amharic Phonetic
                isAmharicLocked = !isAmharicLocked
                currentSyllableBuffer = ""
                
                val msg = if (isAmharicLocked) 
                    "Amharic Language LOCKED (አማርኛ)" 
                else 
                    "English Language UNLOCKED"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                
                updateCandidateStrip()
                keyboardView?.invalidateAllKeys()
            }

            KEYCODE_SYMBOLS -> {
                isSymbolsMode = !isSymbolsMode
                keyboardView?.keyboard = if (isSymbolsMode) symbolsKeyboard else qwertyKeyboard
                keyboardView?.invalidateAllKeys()
            }

            KEYCODE_DELETE -> {
                if (currentSyllableBuffer.isNotEmpty()) {
                    currentSyllableBuffer = ""
                }
                ic.deleteSurroundingText(1, 0)
                updateCandidateStrip()
            }

            KEYCODE_SHIFT -> {
                isShifted = !isShifted
                qwertyKeyboard?.isShifted = isShifted
                keyboardView?.invalidateAllKeys()
            }

            KEYCODE_DONE -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                currentSyllableBuffer = ""
                updateCandidateStrip()
            }

            else -> {
                var codeChar = primaryCode.toChar()
                
                if (isShifted) {
                    codeChar = codeChar.uppercaseChar()
                    isShifted = false
                    qwertyKeyboard?.isShifted = false
                    keyboardView?.invalidateAllKeys()
                }

                if (isAmharicLocked) {
                    // Process key through Windows 10 Amharic Phonetic Engine
                    val res = PhoneticEngineKt.processKey(codeChar.toString(), currentSyllableBuffer)
                    
                    if (res.replaceLength > 0) {
                        ic.deleteSurroundingText(res.replaceLength, 0)
                    }
                    ic.commitText(res.outputChar, 1)
                    currentSyllableBuffer = res.newBuffer
                } else {
                    // Standard English input mode
                    ic.commitText(codeChar.toString(), 1)
                    currentSyllableBuffer = ""
                }
                updateCandidateStrip()
            }
        }
    }

    private fun playFeedback() {
        if (enableVibration) {
            vibrator?.vibrate(20)
        }
        if (enableSound) {
            audioManager?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
    }

    private fun updateCandidateStrip() {
        if (currentSyllableBuffer.isNotEmpty()) {
            val suggestions = PhoneticEngineKt.getSuggestions(currentSyllableBuffer)
            candidateView?.updateCandidates(suggestions)
            setCandidatesViewShown(true)
        } else {
            candidateView?.updateCandidates(emptyList())
            setCandidatesViewShown(false)
        }
    }

    fun pickCandidate(suggestion: String) {
        val ic: InputConnection = currentInputConnection ?: return
        if (currentSyllableBuffer.isNotEmpty()) {
            ic.deleteSurroundingText(1, 0)
        }
        ic.commitText(suggestion, 1)
        currentSyllableBuffer = ""
        setCandidatesViewShown(false)
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
