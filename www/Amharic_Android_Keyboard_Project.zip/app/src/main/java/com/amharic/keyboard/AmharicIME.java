package com.amharic.keyboard;

import android.content.Context;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.media.AudioManager;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Toast;

public class AmharicIME extends InputMethodService implements KeyboardView.OnKeyboardActionListener {

    public static final int KEYCODE_LANG_LOCK = -101;
    public static final int KEYCODE_SHIFT = Keyboard.KEYCODE_SHIFT;
    public static final int KEYCODE_DELETE = Keyboard.KEYCODE_DELETE;
    public static final int KEYCODE_DONE = Keyboard.KEYCODE_DONE;

    private KeyboardView mKeyboardView;
    private Keyboard mQwertyKeyboard;
    private Vibrator mVibrator;
    private AudioManager mAudioManager;
    
    private boolean isAmharicLocked = true;
    private boolean isShifted = false;
    private String currentSyllableBuffer = "";

    @Override
    public void onCreate() {
        super.onCreate();
        mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public View onCreateInputView() {
        mKeyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        mQwertyKeyboard = new Keyboard(this, R.xml.qwerty_layout);
        mKeyboardView.setKeyboard(mQwertyKeyboard);
        mKeyboardView.setOnKeyboardActionListener(this);
        mKeyboardView.setPreviewEnabled(true);
        return mKeyboardView;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        if (mVibrator != null) mVibrator.vibrate(20);
        if (mAudioManager != null) mAudioManager.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);

        switch (primaryCode) {
            case KEYCODE_LANG_LOCK:
                isAmharicLocked = !isAmharicLocked;
                currentSyllableBuffer = "";
                
                String toastMsg = isAmharicLocked ? 
                    "Amharic Language LOCKED (አማርኛ)" : 
                    "English Language UNLOCKED";
                Toast.makeText(this, toastMsg, Toast.LENGTH_SHORT).show();
                
                mKeyboardView.invalidateAllKeys();
                break;

            case KEYCODE_DELETE:
                if (currentSyllableBuffer.length() > 0) {
                    currentSyllableBuffer = "";
                }
                ic.deleteSurroundingText(1, 0);
                break;

            case KEYCODE_SHIFT:
                isShifted = !isShifted;
                mQwertyKeyboard.setShifted(isShifted);
                mKeyboardView.invalidateAllKeys();
                break;

            case KEYCODE_DONE:
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
                ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
                currentSyllableBuffer = "";
                break;

            default:
                char codeChar = (char) primaryCode;
                
                if (isShifted) {
                    codeChar = Character.toUpperCase(codeChar);
                    isShifted = false;
                    mQwertyKeyboard.setShifted(false);
                    mKeyboardView.invalidateAllKeys();
                }

                if (isAmharicLocked) {
                    PhoneticEngine.Result res = PhoneticEngine.processKey(String.valueOf(codeChar), currentSyllableBuffer);
                    
                    if (res.replaceLength > 0) {
                        ic.deleteSurroundingText(res.replaceLength, 0);
                    }
                    ic.commitText(res.outputChar, 1);
                    currentSyllableBuffer = res.newBuffer;
                } else {
                    ic.commitText(String.valueOf(codeChar), 1);
                    currentSyllableBuffer = "";
                }
                break;
        }
    }

    @Override public void onPress(int primaryCode) {}
    @Override public void onRelease(int primaryCode) {}
    @Override public void onText(CharSequence text) {}
    @Override public void swipeLeft() {}
    @Override public void swipeRight() {}
    @Override public void swipeDown() {}
    @Override public void swipeUp() {}
}
